const fs = require('fs')
// ~~~~~~~~~~~ Settings Bot ~~~~~~~~~~~ //
global.connect = true
global.publicX = true
global.autoView = true
global.autoRead = true
global.autoTyping = true
global.prefa = ['','!','/','.',',','🐤','🗿'];

// ~~~~~~~~~~~ Settings Message ~~~~~~~~~~~ //
global.mess = {
  owner: "  `[ Access Denied ]` \n  # Fitur Khusus Owner!",
  prem: "  `[ Access Denied ]` \n  # Fitur Khusus Premium!",
  murbug: "  `[ Access Denied ]` \n  # Fitur Khusus Murbug!",
  reseller: "  `[ Access Denied ]` \n  # Fitur Khusus Reseller!",
  group: "  `[ Access Denied ]` \n  # Fitur Khusus Group!",
  private: "  `[ Access Denied ]` \n  # Fitur Khusus Private!",
  admin: "  `[ Access Denied ]` \n  # Fitur Khusus Admin!",
  limit: "  `[ Access Denied ]` \n  # Fitur Anda Sudah Limit!",
  botadmin: "  `[ Access Denied ]` \n  # Bot Anda Bukan Admin!"
};

// ~~~~~~~~~~~ Settings Reload File ~~~~~~~~~~~ //
let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})